# nombre_del_modulo/__init__.py
from . import models
from . import report
